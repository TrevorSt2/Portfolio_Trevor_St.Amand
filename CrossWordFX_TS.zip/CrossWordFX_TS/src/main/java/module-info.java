module com.example.crosswordfx_ts {
    requires javafx.controls;
    requires javafx.fxml;


    opens com.example.crosswordfx_ts to javafx.fxml;
    exports com.example.crosswordfx_ts;
}