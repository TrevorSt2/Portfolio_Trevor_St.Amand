package com.example.crosswordfx_ts;

import java.io.File;
import java.util.ArrayList;

public class Crossword {
    private Square[][] crossword;
    private String userWord;
    private Clue word;
    private final ArrayList<Clue> crosswordData;
    public Crossword(){
        File file = new File("crossword.txt");
        crosswordData = FileHandler.readFile(file);

        createCrossword();
    }

    private void createCrossword(){
        getMaxSize();

        for (Clue c: crosswordData){
            String word = c.word();
            int row = c.row();
            int col = c.col();

            for (int i = 0; i < word.length(); i++){
                if (i == 0){
                    crossword[row][col] = new Square(String.valueOf(c.order()).charAt(0));
                }

                else {
                    crossword[row][col] = new Square('.');
                }

                if (c.orientation().equals("v")){
                    row++;
                }

                else{
                    col++;
                }
            }
        }

        for (int row = 0; row < crossword.length; row++){
            for (int col = 0; col < crossword[0].length; col++){
                if (crossword[row][col] == null){
                    crossword[row][col] = new Square('*');
                }
            }
        }
    }

    //makes the crossword the necessary size to hold all the words
    private void getMaxSize(){
        int maxRow = 0;
        int maxCol = 0;
        int num = 0;
        int num2 = 0;

        for (int i = 0; i < crosswordData.size(); i++){
            Clue c = crosswordData.get(i);

            if (c.row() > maxRow && c.orientation().equals("v")){
                maxRow = c.row();
                num = i;
            }

            if (c.col() > maxCol && c.orientation().equals("h")){
                maxCol = c.col();
                num2 = i;
            }
        }

        maxRow += crosswordData.get(num).word().length();
        maxCol += crosswordData.get(num2).word().length();


        crossword = new Square[maxRow][maxCol];
    }

    public void printBoard(){
        for (Square[] squareArray : crossword){
            for (Square square : squareArray){
                System.out.print(square.getLetter() + "\t");
            }
            System.out.println();
        }
    }

    public void takeTurn(int wordNum, String userWord){
        word = crosswordData.get(wordNum - 1);
        this.userWord = userWord.toUpperCase();

        if (checkWordLength() && checkConflictingLetters() && checkIfNums()){
            printWord();
        }
    }

    private void printWord(){
        int row = word.row();
        int col = word.col();
        userWord = userWord.toUpperCase();

        for (int i = 0; i < userWord.length(); i++){
            crossword[row][col].setLetter(userWord.charAt(i));

            if (word.orientation().equals("v")){
                row++;
            }

            else {
                col++;
            }
        }
    }

    private boolean checkWordLength(){
        if (userWord.length() == word.word().length()){
            return true;
        }

        System.out.println("Word has to be the same length as empty space");
        return false;
    }

    private boolean checkConflictingLetters(){
        //these two variables and this for loop are in 8 different spots and it is so bad. Find a more efficient replacement
        int row = word.row();
        int col = word.col();
        userWord = userWord.toUpperCase();

        for (int i = 0; i < userWord.length(); i++){
            char letter = crossword[row][col].getLetter();
            try{
                Integer.parseInt(String.valueOf(letter));
            }

            catch (Exception e){
                if (letter != '.' && (int)letter != userWord.charAt(i)){
                    System.out.println("The letters in this word must match the letters in the existing word");
                    return false;
                }
            }

            if (word.orientation().equals("v")) {
                row++;
            }

            else{
                col++;
            }
        }
        return true;
    }

    public ArrayList<Clue> displayClues(){
        ArrayList<Clue> clueSorted = new ArrayList<>();

        for (Clue clue : crosswordData){
            if (clue.orientation().equals("v")){
                clueSorted.add(0, clue);
            }

            else{
                clueSorted.add(clue);
            }
        }

        return clueSorted;
    }

    public void getSpecificClue(int num){
        Clue clue = crosswordData.get(num - 1);

        System.out.println(clue.order() + ":" + convertToWord(clue.orientation()) + " - " + clue.clue());
    }

    public void eraseAnswer(int num) {
        Clue clue = crosswordData.get(num - 1);

        int row = clue.row();
        int col = clue.col();

        for (int i = 0; i < clue.word().length(); i++) {
            if (!checkForLetters(row, col, clue.orientation())) {
                if (i == 0) {
                    crossword[row][col].setLetter(String.valueOf(clue.order()).charAt(0));
                } else {
                    crossword[row][col].setLetter('.');
                }


            }
            if (clue.orientation().equals("v")) {
                row++;
            } else {
                col++;
            }
        }
    }

    public void exitGame(){
        System.exit(0);
    }

    public void submitPuzzle(){
        for (Clue clue : crosswordData) {
            int row = clue.row();
            int col = clue.col();

            for (int k = 0; k < clue.word().length(); k++) {
                if (crossword[row][col].getLetter() != clue.word().toUpperCase().charAt(k)) {
                    System.out.println("At least one of your answers is incorrect");
                    return;
                }

                if (clue.orientation().equals("v")) {
                    row++;
                }

                else
                {
                    col++;
                }
            }
        }
        System.out.println("Congratulations! You Won!");
        exitGame();
    }

    public String convertToWord(String str){
        if (str.equals("v")){
            return "Down";
        }

        return "Across";
    }

    public boolean checkIfNums(){
        for(int i = 0; i < userWord.length(); i++){
            try{
                Integer.parseInt(String.valueOf(userWord.charAt(i)));
                System.out.println("Word may not contain numbers");
                return false;
            }

            catch (Exception ignored){

            }
        }

        return true;
    }

    public boolean checkForLetters(int row, int col, String orientation){

        if (orientation.equals("h") && ((row - 1 >= 0 && isLetter(crossword[row - 1][col].getLetter())) || (row + 1 < crossword.length && isLetter(crossword[row + 1][col].getLetter())))){
            return true;
        }

        else return orientation.equals("v") && ((col - 1 >= 0 && isLetter(crossword[row][col - 1].getLetter())) || (col + 1 < crossword.length && isLetter(crossword[row][col + 1].getLetter())));
    }

    public boolean isLetter(char chr){

        return ((int) chr >= 65 && (int) chr <= 90) || ((int) chr >= 97 && (int) chr <= 122);
    }

    public Square[][] getCrossword(){
        return crossword;
    }
}
