package com.example.crosswordfx_ts;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.input.KeyEvent;
import javafx.stage.Stage;

import java.io.IOException;

public class HelloApplication extends Application {
    @Override
    public void start(Stage stage) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("hello-view.fxml"));
        Scene scene = new Scene(fxmlLoader.load(), 320, 240);
        stage.setTitle("Hello!");
        stage.setScene(scene);
        stage.show();

        HelloController controller = fxmlLoader.getController();

        scene.setOnKeyPressed(new EventHandler<KeyEvent>() {
            public void handle(KeyEvent event) {

                switch (event.getCode()){
                    case UP -> controller.moveUp(-1);

                    case DOWN -> controller.moveUp(1);

                    case RIGHT -> controller.moveRight(1);

                    case LEFT -> controller.moveRight(-1);

                    case BACK_SPACE -> {
                        controller.eraseLabel();
                        controller.moveRight(-1);
                    }
                }

                if (String.valueOf(event.getCode()).length() == 1){
                    System.out.println(event.getCode());
                    controller.setText(event.getText().toUpperCase());
                    controller.incrementThing();
                }
            }
        });
    }



    public static void main(String[] args) {
        launch();
    }
}