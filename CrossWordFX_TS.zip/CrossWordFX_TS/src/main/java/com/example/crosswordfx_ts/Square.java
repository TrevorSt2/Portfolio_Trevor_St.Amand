package com.example.crosswordfx_ts;

public class Square {
    private char letter;
    public Square(char letter){
        this.letter = letter;
    }

    public char getLetter(){
        return letter;
    }

    public void setLetter(char letter) {
        this.letter = letter;
    }
}
