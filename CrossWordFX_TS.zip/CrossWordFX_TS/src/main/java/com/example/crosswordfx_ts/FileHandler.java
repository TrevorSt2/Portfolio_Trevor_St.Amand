package com.example.crosswordfx_ts;

import java.io.*;
import java.util.Scanner;
import java.util.ArrayList;

public class FileHandler {
    public static ArrayList<Clue> readFile(File file){
        try{
            ArrayList<Clue> list = new ArrayList<>();
            Scanner fileInput = new Scanner(file);

            while (fileInput.hasNext()){
                String[] crosswordData = fileInput.nextLine().split(":");

                //I feel like there is more here than there needs to be -- maybe just parseInt when making the clue
                ArrayList<Integer> crossNums = new ArrayList<>();
                ArrayList<String> crossWords = new ArrayList<>();

                for (String crosswordDatum : crosswordData) {
                    try {
                        crossNums.add(Integer.parseInt(crosswordDatum));
                    } catch (Exception e) {
                        crossWords.add(crosswordDatum);
                    }
                }

                list.add(new Clue (crossNums.get(0), crossNums.get(1), crossWords.get(0), crossNums.get(2), crossWords.get(1), crossWords.get(2)));
            }

            return list;
        }

        catch (Exception e){
            Scanner scanner = new Scanner(System.in);

            System.out.println("Error - File not found");
            System.out.println("Enter the name of the file: ");

            File newFile = new File(scanner.nextLine());

            return readFile(newFile);
        }
    }
}
