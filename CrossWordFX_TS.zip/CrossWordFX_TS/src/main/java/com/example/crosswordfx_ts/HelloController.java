package com.example.crosswordfx_ts;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.TextArea;
import javafx.scene.input.KeyEvent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;

import java.net.URL;
import java.security.Key;
import java.util.ArrayList;
import java.util.ResourceBundle;

public class HelloController implements Initializable {
    //region Variables
    private Rectangle currRect;
    @FXML
    private Rectangle[][] rectList;
    @FXML
    private TextArea clueBox;

    private Scene scene;
    private Label[][] labelList;
    private Crossword crossword;
    private Label currentLabel;
    int currRow;
    int currCol;
    String orientation;

    @FXML
    private Label welcomeText;

    @FXML
    private AnchorPane pane;
    //endregion
    private void createCrosswordGrid(int rows, int cols){
        rectList = new Rectangle[rows][cols];
        labelList = new Label[rows][cols];
        pane.addEventFilter(MouseEvent.MOUSE_CLICKED, selectRect);

        for (int row = 0; row < rows; row++){
            for (int col = 0; col < cols; col++){
                rectList[row][col] = new Rectangle();
                labelList[row][col] = new Label();

                Label label = labelList[row][col];
                Rectangle rect = rectList[row][col];

                rect.setId(row + "," + col);

                rect.setWidth(30);
                rect.setHeight(30);
                rect.setLayoutX(col * (rect.getHeight() + 2) + 100);
                rect.setLayoutY(row * (rect.getWidth() + 2) + 100);
                rect.setFill(Color.ORANGE);
                rect.setStrokeWidth(1);
                rect.setStroke(Color.BLACK);

                label.setLayoutY(rect.getLayoutY() + 7);
                label.setLayoutX(rect.getLayoutX() + 11);
                label.setDisable(true);

                pane.getChildren().add(rect);
                pane.getChildren().add(label);
            }
        }
    }

    public void event (KeyEvent event){
        System.out.println(event.getCode());
        System.out.println("ASDFJIO");

    }

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        crossword = new Crossword();
        createCrosswordGrid(crossword.getCrossword().length, crossword.getCrossword()[0].length);
        setColorOfSquares();
        crossword.printBoard();
        fillClueBox();
    }

    private void setColorOfSquares(){
        for (int i = 0; i < rectList.length; i++){
            for (int j = 0; j < rectList[0].length; j++){
                Rectangle rect = rectList[i][j];

                if (crossword.getCrossword()[i][j].getLetter() != '*'){
                    if (crossword.getCrossword()[i][j].getLetter() != '.'){
                        Label label = new Label();
                        label.setLayoutX(rect.getLayoutX() + 2);
                        label.setLayoutY(rect.getLayoutY());
                        label.setText(String.valueOf(crossword.getCrossword()[i][j].getLetter()));
                        label.toFront();
                        label.setTextFill(Color.BLACK);
                        label.setDisable(true);

                        pane.getChildren().add(label);
                    }
                    rect.setFill(Color.WHITE);
                }

                else{
                    rect.setFill(Color.BLACK);
                    rect.setStroke(null);
                }
            }
        }
    }

    EventHandler<MouseEvent> selectRect = event ->{
        Rectangle rect = (Rectangle) event.getTarget();

        if (rect.getFill() == Color.WHITE){
            if (currRect != null) {
                currRect.setFill(Color.WHITE);
            }

            rect.setFill(Color.SKYBLUE);
            String[] stringCoords = rect.getId().split(",");

            int row = Integer.parseInt(stringCoords[0]);
            int col = Integer.parseInt(stringCoords[1]);

            boolean test1 = true;
            boolean test2 = true;

            if (row - 1 >= 0){
                if (rectList[row - 1][col].getFill() == Color.WHITE){
                    test1 = false;
                }
            }

            if (row + 1 < rectList.length){
                if (rectList[row + 1][col].getFill() == Color.WHITE){
                    test2 = false;
                }
            }

            if (test1 && test2){
                orientation = "v";
            }

            else {
                orientation = "h";
            }

            currRect = rect;
            currentLabel = labelList[row][col];
            currRow = row;
            currCol = col;
        }
    };

    public void setText(String text){
        currentLabel.setText(text);
    }

    public void incrementThing(){
        if (currCol + 1 < rectList[0].length && rectList[currRow][currCol + 1].getFill() == Color.WHITE && orientation.equals("v")){
            currCol++;
        }

        if (currRow + 1 < rectList.length && rectList[currRow + 1][currCol].getFill() == Color.WHITE && orientation.equals("h")){
            currRow++;
        }

        currentLabel = labelList[currRow][currCol];

        currRect.setFill(Color.WHITE);

        currRect = rectList[currRow][currCol];
        currRect.setFill(Color.SKYBLUE);
    }

    public void moveUp(int num){
        try{
            if (rectList[currRow + num][currCol].getFill() != Color.BLACK){
                currRect.setFill(Color.WHITE);

                currRow += num;
                currRect = rectList[currRow][currCol];
                currRect.setFill(Color.SKYBLUE);

                currentLabel = labelList[currRow][currCol];
            }
        }

        catch (Exception ignored){

        }
    }

    public void moveRight(int num){
        try{
            if (rectList[currRow][currCol+ num].getFill() != Color.BLACK){
                currRect.setFill(Color.WHITE);

                currCol += num;
                currRect = rectList[currRow][currCol];
                currRect.setFill(Color.SKYBLUE);

                currentLabel = labelList[currRow][currCol];
            }
        }

        catch (Exception ignored){

        }
    }

    public void eraseLabel(){
        currentLabel.setText("");
    }

    public void fillClueBox(){
        ArrayList<Clue> clues = crossword.displayClues();

        clueBox.setText("DOWN\n-------------------------------------------------\n");

        for (Clue clue : clues){
            if (clue.orientation().equals("v")){
                clueBox.setText(clueBox.getText() + clue.order() + " : " + clue.clue() + "\n");
            }

            else{
                break;
            }
        }

        clueBox.setText(clueBox.getText() + "\nACROSS\n-------------------------------------------------\n");

        for (Clue clue : clues){
            if (clue.orientation().equals("h")){
                clueBox.setText(clueBox.getText() + clue.order() + " : " + clue.clue() + "\n");
            }
        }
    }

    public String getOrientation(){
        return orientation;
    }
//need to make variable to hold rectangle and row/col so we can se
}