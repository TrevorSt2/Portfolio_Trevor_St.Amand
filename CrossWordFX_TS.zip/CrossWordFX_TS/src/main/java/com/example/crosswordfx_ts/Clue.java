package com.example.crosswordfx_ts;

public record Clue(int row, int col, String orientation, int order, String word, String clue) {
}
